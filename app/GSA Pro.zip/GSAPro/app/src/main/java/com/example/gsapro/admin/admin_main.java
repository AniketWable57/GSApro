package com.example.gsapro.admin;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.drawerlayout.widget.DrawerLayout;

import com.example.gsapro.R;
import com.google.android.material.navigation.NavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

public class admin_main extends AppCompatActivity {

    private DrawerLayout drawerLayout;
    private ActionBarDrawerToggle toggle;
    private NavigationView navigationView;
    private TextView adminUsername, adminMail;
    private FirebaseAuth mAuth;
    private FirebaseFirestore db;

    @SuppressLint("WrongViewCast")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_admin_main);

        drawerLayout = findViewById(R.id.drawer);
        navigationView = findViewById(R.id.navigationView);
        adminUsername = findViewById(R.id.adminusername);
        adminMail = findViewById(R.id.adminemail);
        

        // Initialize Firebase Auth and Firestore
        mAuth = FirebaseAuth.getInstance();
        db = FirebaseFirestore.getInstance();

        // Get current user
        FirebaseUser currentUser = mAuth.getCurrentUser();

        if (currentUser != null) {
            // Set email
            adminMail.setText(currentUser.getEmail());
            // Fetch username from Firestore
            fetchUsername(currentUser.getUid());
        } else {
            Toast.makeText(this, "No user is logged in", Toast.LENGTH_SHORT).show();
        }

        // Setup drawer
        setupDrawer();
    }

    private void fetchUsername(String userId) {
        db.collection("users").document(userId).get().addOnCompleteListener(task -> {
            if (task.isSuccessful() && task.getResult() != null) {
                DocumentSnapshot document = task.getResult();
                if (document.exists()) {
                    String username = document.getString("username"); // Adjust based on your Firestore structure
                    adminUsername.setText(username);
                } else {
                    Toast.makeText(this, "Username not found", Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(this, "Error fetching username", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void setupDrawer() {
        toggle = new ActionBarDrawerToggle(this, drawerLayout, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawerLayout.addDrawerListener(toggle);
        toggle.syncState();

        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {

                int itemId = item.getItemId();

                if (itemId == R.id.viewProfile){
                    Toast.makeText(admin_main.this, "Vew Profile Clicked", Toast.LENGTH_SHORT).show();
                }

                if (itemId == R.id.addGramsevak){
                    Intent toAddGramSevakpage = new Intent(admin_main.this, add_gramsevak.class);
                    startActivity(toAddGramSevakpage);

                }

                if (itemId == R.id.addScheme){
                    Intent toAddNewScheme = new Intent(admin_main.this, add_new_schemes.class);
                    startActivity(toAddNewScheme);
                }

                if (itemId == R.id.gramsevakList){
                    Intent toGramsevakList = new Intent(admin_main.this, gramsevak_list.class);
                    startActivity(toGramsevakList);

                }
                if (itemId == R.id.SchemeList){
                    Intent toSchemeList = new Intent(admin_main.this, view_schemes.class);
                    startActivity(toSchemeList);

                }

                drawerLayout.close();

                return false;
            }
        });
    }
}
